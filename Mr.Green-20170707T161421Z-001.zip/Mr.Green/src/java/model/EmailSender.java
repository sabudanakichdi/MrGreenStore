
package model;

import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class EmailSender {

    private static final String SENDER_EMAIL = "grenmr18@gmail.com";
    private static final String PASSWORD = "mrgreen123";

    public static void sendEmail(Customer user, emailType type, String otp) {

        
        String to = user.getEmail();
        // Sender's email ID needs to be mentioned
        //String from = SENDING_EMAIL;
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props,
                new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(SENDER_EMAIL, PASSWORD);
            }
        });

        try {
            // Create a default MimeMessage object.
            MimeMessage message = new MimeMessage(session);
            // Set From: header field of the header.
            message.setFrom(new InternetAddress(SENDER_EMAIL));
            // Set To: header field of the header.
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));

            if (type == emailType.REGISTER) {
                // Set Subject: header field
                message.setSubject("Mr.Green.com Confirmation Email");
                // Now set the actual message
                message.setText("Your Otp :"+otp);
            }
            else if(type == emailType.FORGOT_PASSWORD) {
            // Set Subject: header field
                message.setSubject("Mrgreen.com Reset Password Email");
                // Now set the actual message
                message.setText("Your OTP : "+otp);//otp check
                
            }

            System.out.println("HERE");
            Transport.send(message);
            System.out.println("Sent message successfully....");
        } catch (MessagingException mex) {
            System.out.println("EXCeptioN");
            mex.printStackTrace();
        }

    }

    public static void main(String args[]) {
        Customer user = new Customer();
        user.setUsername("varun");
        user.setVcode(4263);
        user.setEmail("varun8338@gmail.com");//
        String otp= "4263";
      
                sendEmail(user, emailType.REGISTER,otp);
    }
}
