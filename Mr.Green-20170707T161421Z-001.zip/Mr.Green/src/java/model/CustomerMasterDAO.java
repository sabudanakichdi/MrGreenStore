/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Vivek
 */
public class CustomerMasterDAO extends BaseDAO{
Connection connection;
    PreparedStatement preparedStatement;
    Statement statement;
    ResultSet rs;
    public void createAccount(Customer c, String otp) {
    try {
        //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        connection = getConnection();
    } catch (ClassNotFoundException | SQLException ex) {
        Logger.getLogger(CustomerMasterDAO.class.getName()).log(Level.SEVERE, null, ex);
    }
        String sql = "insert into customers values(?,?,?,?,?,?,?)";
        try {
            preparedStatement= connection.prepareStatement(sql);
            preparedStatement.setString(1,c.getUsername());
            preparedStatement.setString(2,c.getPassword());
            preparedStatement.setString(3,c.getEmail());
            preparedStatement.setString(4,c.getPhone());
            preparedStatement.setString(5,c.getZipcode());
            preparedStatement.setString(6,c.getAddress());
            preparedStatement.setString(7,otp);
            
           /* preparedStatement.setString(3,c.getLastName());
            preparedStatement.setString(4,c.getTitle());
            preparedStatement.setString(5,c.getDepartment());
            preparedStatement.setString(6,c.getEmail());
        */
                int count = preparedStatement.executeUpdate();
                
                if(count>0)
                {
                    System.out.println("Successfully Inserted");
                }else{
                    System.out.println("insertion failed");
                }
                } catch (SQLException ex) {
                    Logger.getLogger(CustomerMasterDAO.class.getName()).log(Level.SEVERE, null, ex);
                }
        
    }
public  boolean checkLogin(Customer c)
    {
        try {
            connection = getConnection();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CustomerMasterDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(CustomerMasterDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
           String sql = "select * from customers where username=? AND password= ?";
        try {
                preparedStatement = connection.prepareStatement(sql);
                
                preparedStatement.setString(1,c.getUsername());
                
                preparedStatement.setString(2,c.getPassword());
            
                rs=preparedStatement.executeQuery();
                while( rs.next())
              {
              return true;
              }
        } catch (SQLException ex) {
            Logger.getLogger(CustomerMasterDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
       
         return false;
    }
    


public  boolean checkUsername(Customer c)
    {
        try {
            connection=getConnection();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CustomerMasterDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(CustomerMasterDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
           String sql = "select * from customers where username=? and email=?";
        try {
                preparedStatement = connection.prepareStatement(sql);
                
                preparedStatement.setString(1,c.getUsername());
                preparedStatement.setString(2,c.getEmail());
                
            
                rs=preparedStatement.executeQuery();
                while( rs.next())
                {
              return true;
              }
        } catch (SQLException ex) {
            Logger.getLogger(CustomerMasterDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
       
         return false;
    }
public  void updateOtpDao(Reset r)
    {
        try {
            connection=getConnection();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CustomerMasterDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(CustomerMasterDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
           String sql = "update customers set otp = ? where username = ?";
        try {
                preparedStatement = connection.prepareStatement(sql);
                preparedStatement.setString(1,r.getOtp());
                preparedStatement.setString(2,r.getUsername());
                
            
                preparedStatement.executeUpdate();
               
        } catch (SQLException ex) {
            Logger.getLogger(CustomerMasterDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        
    }
    
}