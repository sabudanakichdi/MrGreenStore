/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Vivek
 */
public class Customer {

    
    private String username;
    private String password;
    private String password_confirm;
    private String email;
    private String phone;
    private String address;
    private String zipcode;

    public String getPassword_confirm() {
        return password_confirm;
    }

    public void setPassword_confirm(String password_confirm) {
        this.password_confirm = password_confirm;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    /**
     *
     * @param request
     * @param response
     * @return
     */
    public static Customer populateData(HttpServletRequest request, HttpServletResponse response)
    {
        Customer c =new Customer();
           //c.setCustomerId(Integer.parseInt(request.getParameter("customerId")));
           c.setUsername(request.getParameter("usernamesignup"));
           c.setEmail(request.getParameter("email"));
           c.setPhone(request.getParameter("phone"));
           c.setAddress(request.getParameter("address"));
           c.setZipcode(request.getParameter("zipcode"));
           c.setPassword(request.getParameter("passwordsignup"));
           c.setPassword_confirm(request.getParameter("passwordsignup_confirm"));
          // c.setTitle(request.getParameter("title"));
          // c.setDepartment(request.getParameter("department"));
          // c.setEmail(request.getParameter("email"));
           return c;
    }

    String getVcode() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setVcode(int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
