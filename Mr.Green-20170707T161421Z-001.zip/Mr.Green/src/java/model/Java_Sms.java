
package model;
import java.net.*;

public class Java_Sms {

        public static void main(String[] args) {
            String otp="4444";
            String contact="+918108855572";
            sendSms(otp,contact);
        }
            public static void sendSms(String otp, String contact){
                try {
                        String recipient = "+91"+contact;
                        //String message = "Hello World";
                        String username = "admin";
                        String password = "samson";
                        String originator = "+918976434118";
 
                        String requestUrl  = "http://127.0.0.1:9501/api?action=sendmessage&" +
            "username=" + URLEncoder.encode(username, "UTF-8") +
            "&password=" + URLEncoder.encode(password, "UTF-8") +
            "&recipient=" + URLEncoder.encode(recipient, "UTF-8") +
            "&messagetype=SMS:TEXT" +
            "&messagedata=" + URLEncoder.encode("Mr.Green's Store.Your OTP is-" + otp,"UTF-8") +
            "&originator=" + URLEncoder.encode(originator, "UTF-8") +
            "&serviceprovider=SMPP0" +
            "&responseformat=html";
           


                        URL url = new URL(requestUrl);
                        HttpURLConnection uc = (HttpURLConnection)url.openConnection();

                        System.out.println(uc.getResponseMessage());

                        uc.disconnect();

                } catch(Exception ex) {
                        System.out.println(ex.getMessage());

                }
        }

}