
package model;

import java.util.Random;

/**
 *
 * @author Dell
 */
public class OtpGenerator {
    int otp;
    public static int generateOTP() {
        Random r = new Random();
        return (r.nextInt(9)+1) + (r.nextInt(9)+1)*10 + (r.nextInt(9)+1)*100 + (r.nextInt(9)+1)*1000;
    }
    public static void main(String [] args) {
        OtpGenerator o = new OtpGenerator();
        int otp = o.generateOTP();
        System.out.println(otp);
        
            
    }
    
}
