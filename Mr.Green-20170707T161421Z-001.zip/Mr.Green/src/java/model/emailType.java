package model;

    public enum emailType {
        REGISTER,
        FORGOT_PASSWORD
    }