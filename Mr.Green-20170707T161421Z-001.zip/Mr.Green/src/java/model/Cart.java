/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author prateekchauhan
 */
public class Cart {
   public ArrayList<Product> cartList;

    public ArrayList<Product> getCartList() {
        return cartList;
    }

    public void setCartList(ArrayList<Product> cartList) {
        this.cartList = cartList;
    }
   
   public Cart() {
       cartList = new ArrayList();
   }

   public void addProduct(Product l){
       
       cartList.add((Product)l);
       System.out.println("Heyy I m here!!");
   }

}
