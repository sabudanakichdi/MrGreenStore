/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author prateekchauhan
 */
public class Reset {
    String username;
    String otp;
    String phone;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }
    public static Reset populateData(HttpServletRequest request, HttpServletResponse response)
    {
        Reset c =new Reset();
           //c.setCustomerId(Integer.parseInt(request.getParameter("customerId")));
           c.setUsername(request.getParameter("usernamesignup"));
           c.setOtp(request.getParameter("otp"));
           c.setPhone(request.getParameter("contact"));
        return c;
    }
}