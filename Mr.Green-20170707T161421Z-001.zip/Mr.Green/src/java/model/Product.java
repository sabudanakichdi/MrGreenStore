/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author prateekchauhan
 */
public class Product 
{
    String p_id;
    String p_name;
    String p_price;
    String category;
    String pics;

    public String getPics() {
        return pics;
    }

    public void setPics(String pics) {
        this.pics = pics;
    }

    public String getP_id() {
        return p_id;
    }

    public void setP_id(String p_id) {
        this.p_id = p_id;
    }

    public String getP_name() {
        return p_name;
    }

    public void setP_name(String p_name) {
        this.p_name = p_name;
    }

    public String getP_price() {
        return p_price;
    }

    public void setP_price(String p_price) {
        this.p_price = p_price;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
    
       public static Product populateData(HttpServletRequest request, HttpServletResponse response) {
        
        Product p = new Product();
        p.setP_id(request.getParameter("p_id"));
        p.setP_name(request.getParameter("p_name"));
        p.setP_price(request.getParameter("p_price"));
        p.setCategory(request.getParameter("p_category"));
        p.setPics(request.getParameter("pics"));
        
        return p;
        
       } 
}
