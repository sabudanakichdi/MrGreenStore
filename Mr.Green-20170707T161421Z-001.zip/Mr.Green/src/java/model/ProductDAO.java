/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author nigelkoli
 */
public class ProductDAO extends BaseDAO{
    
    Connection con;
    PreparedStatement preparedStatement;
    Statement statement;
    ResultSet rs;
    
    public Product findProductByID(String  p_id)
    {    Product prod=new Product();
        
       
        try {
            con = getConnection();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
             String sql="select * from products where products_id = ?";
            preparedStatement=con.prepareStatement(sql);
            preparedStatement.setString(1,p_id);
          
            rs=preparedStatement.executeQuery();
            while(rs.next())
            {   Product p  = new Product();
                System.out.println("test");
                p.setP_id(rs.getString(1));
                p.setP_name(rs.getString(2));
                p.setP_price(rs.getString(5));
                p.setCategory(rs.getString(3));
//                c.setp_id(rs.getInt(1));
//                c.setMedName(rs.getString(2));
//                c.setQuant(rs.getInt(3));
//                //c.setExpdate(rs.getInt(4));
//                c.setPrice(rs.getInt(4));
              
              prod=p;
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return prod;
    }
  
     public List findProductByCategory(String category)
    {      
        ArrayList<Product> addList = new ArrayList();
        
       
        try {
            con = getConnection();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
             String sql="select * from products where products.category = ?";
            preparedStatement=con.prepareStatement(sql);
            preparedStatement.setString(1,category);
          
            rs=preparedStatement.executeQuery();
            
            while(rs.next())
            {   Product p  = new Product();
                System.out.println("test");
                p.setP_id(rs.getString(1));
                p.setP_name(rs.getString(2));
                p.setP_price(rs.getString(5));
                p.setCategory(rs.getString(3));
                p.setPics(rs.getString(4));

              
              addList.add(p);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ProductDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return addList;
    }
}
